export const STORAGE_KEY="sasha-photography-accounting-v11";
export const TAX_RATE=0.13;
export const HOTEL_INFO={
 "Four Seasons":{name:"Four Seasons Resort Bora Bora",address:"Motu Tehotu, Bora Bora, French Polynesia",code:"FSBB"},
 Westin:{name:"The Westin Bora Bora Resort & Spa",address:"Motu Tape, Bora Bora, French Polynesia",code:"WEST"},
 "Le Bora Bora":{name:"Le Bora Bora by Pearl Resorts",address:"Motu Tevairoa, Bora Bora, French Polynesia",code:"LBB"},
 "Le Moana":{name:"InterContinental Bora Bora Le Moana Resort",address:"Matira Point, Bora Bora, French Polynesia",code:"LM"},
 Thalasso:{name:"InterContinental Bora Bora Resort & Thalasso Spa",address:"Motu Piti Aau, Bora Bora, French Polynesia",code:"THAL"},
 "St. Regis":{name:"The St. Regis Bora Bora Resort",address:"Motu Omee, Bora Bora, French Polynesia",code:"SRBB"},
 Conrad:{name:"Conrad Bora Bora Nui",address:"Motu Toopua, Bora Bora, French Polynesia",code:"CON"},
 Mainland:{name:"Mainland / Matira",address:"Bora Bora, French Polynesia",code:"MAIN"}
};
export const HOTELS=Object.keys(HOTEL_INFO);
export const PACKAGES=["50 photos","100 photos","150 photos","200 photos","Event / Custom"];
export const EVENT_TYPES=["Honeymoon","Wedding","Anniversary","Proposal","Engagement","Family","Portrait","Event"];
export const SOURCES=["Resort","Direct"];
export const DEPARTMENTS=["Concierge","Event"];
export const INVOICE_DEPARTMENTS=["All Departments",...DEPARTMENTS];
export const STATUSES=["Paid","To invoice","Invoice sent","Unpaid"];
export const TABS=["Dashboard","Shoots","Direct","Invoices","Prices"];
export const MONTHS=[["01","January"],["02","February"],["03","March"],["04","April"],["05","May"],["06","June"],["07","July"],["08","August"],["09","September"],["10","October"],["11","November"],["12","December"]];
export const MONTH_CODES={01:"JAN",02:"FEB",03:"MAR",04:"APR",05:"MAY",06:"JUN",07:"JUL",08:"AUG",09:"SEP",10:"OCT",11:"NOV",12:"DEC"};
export const initialPricing=[
 {id:1,hotel:"Four Seasons",photoPackage:"50 photos",ht:74000},
 {id:2,hotel:"Four Seasons",photoPackage:"100 photos",ht:120000},
 {id:3,hotel:"Westin",photoPackage:"50 photos",ht:74000},
 {id:4,hotel:"Le Moana",photoPackage:"100 photos",ht:110000}
];
export const initialShoots=[
 {id:1,date:"2026-05-02",hotel:"St. Regis",client:"Yu & Shi",eventType:"Wedding",photoPackage:"100 photos",department:"Event",source:"Resort",ht:90000,tax:11700,finalAmount:101700,status:"To invoice"},
 {id:2,date:"2026-05-09",hotel:"Conrad",client:"Amanda & Randy",eventType:"Proposal",photoPackage:"50 photos",department:"Concierge",source:"Direct",ht:71000,tax:9230,finalAmount:80230,status:"Paid"},
 {id:3,date:"2026-05-14",hotel:"Four Seasons",client:"Employee Event",eventType:"Event",photoPackage:"Event / Custom",department:"Event",source:"Resort",ht:120000,tax:15600,finalAmount:135600,status:"To invoice"}
];
export const initialDirect=[{id:1,date:"2026-05-10",client:"Amber",income:"Full gallery",amount:300,method:"PayPal"}];
export const emptyShoot={date:"2026-05-21",hotel:"Four Seasons",client:"",eventType:"Honeymoon",photoPackage:"50 photos",department:"Concierge",source:"Resort",ht:"74000",tax:"9620",finalAmount:"83620",status:"To invoice"};
export const emptyDirect={date:"2026-05-21",client:"",income:"Extra photos",amount:"150",method:"PayPal"};
export const emptyPrice={hotel:"Four Seasons",photoPackage:"50 photos",ht:"74000"};
