import{STORAGE_KEY}from"../data/constants.js";
export function load(){try{return JSON.parse(localStorage.getItem(STORAGE_KEY)||"null")}catch{return null}}
export function save(data){localStorage.setItem(STORAGE_KEY,JSON.stringify(data))}
export function backup(name,data){const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=name;a.click();URL.revokeObjectURL(url)}
